package net.sourceforge.javacsv.javacsv;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

public class CsvReaderExample {

	public static void main(String[] args) throws IOException {
		
		//Using sourceforge javaCSV dependency
		/*try {
			
			CsvReader products = new CsvReader("Book1.csv");
		
			products.readHeaders();

			while (products.readRecord())
			{
				String productID = products.get("name");
				String productName = products.get("place");
				String supplierID = products.get("class");
				String categoryID = products.get("rank");
				// perform program logic here
				System.out.println(productID + ":" + productName);
			}
	
			products.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		
		//Using apache commons CSV
		Reader in;
		try {
			in = new FileReader("Book1.csv");
			Iterable<CSVRecord> records = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(in);
			for (CSVRecord record : records) {
			    String name = record.get("name");
			    String place = record.get("place");
			    String classs = record.get("class");
			    System.out.println(name+","+place+","+classs);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
