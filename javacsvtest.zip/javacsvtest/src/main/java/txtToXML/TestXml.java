package txtToXML;

import java.io.File;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class TestXml {

	public static void main(String[] args) {
		final String TXT_PATH = "D:/TXT_one.txt";
		final String XSLT_PATH = "D:/XSLT_one.xslt";
		final String XML_PATH = "D:/test_xml_result_one.xml";

		TransformerFactory tFactory = new TransformerFactoryImpl();
		Transformer transformer = tFactory.newTransformer(new StreamSource(new File(XSLT_PATH)));
		transformer.transform(new StreamSource(new File(TXT_PATH)), new StreamResult(new File(XML_PATH)));

		System.out.println("Output written to text file");

	}

}
