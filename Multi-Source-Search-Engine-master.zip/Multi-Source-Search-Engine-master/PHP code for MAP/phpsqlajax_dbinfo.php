<?php
/***********************************************************************
 * Credentials to Mysql DB
 **********************************************************************/
header('Content-type: text/xml; charset=utf-8');
$username="root";
$password="XXXXXXXXX";
$database="GoogleMaps";
?>
