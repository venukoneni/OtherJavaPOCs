<?php
header('Content-type: text/xml; charset=utf-8');
$username="root";
$password="finalfantasy";
$database="GoogleMaps";
?>
